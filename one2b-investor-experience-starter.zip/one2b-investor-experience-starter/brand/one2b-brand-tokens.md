# One 2b Brand Tokens

## Palette

- Base white: #FFFFFF
- Lavender: #EAE4F4
- Periwinkle: #D2DCEC
- Peach: #F1DDD0
- Display ink: #1B2540
- Body slate: #4A5266

## Direction

Soft authority. Premium editorial. Considered institutional composition.

Not dark institutional. Not glassy SaaS. Not crypto.

## Layout

- Generous whitespace
- Magazine-grade hierarchy
- Upper-right soft gradient field
- Deep navy typography
- Quiet motion
- Editorial pacing

## Typography

- Display: Inter, weight 300
- Eyebrow: Inter, weight 400, tracked-out uppercase
- Body: system stack or Inter
