import React from "react";
import { motion } from "framer-motion";

const sections = [
  {
    eyebrow: "ORTRAX · ONE2B",
    title: "Data is becoming an asset class.",
    body: "One 2b produces IVSC-compliant data valuations through Tesseract and supports data-purchase transactions through IGI."
  },
  {
    eyebrow: "VALUATION · ASSURANCE",
    title: "The unlock is confidence.",
    body: "Tesseract establishes valuation discipline. IGI provides a 30-day repayment guarantee on qualified data-purchase transactions."
  },
  {
    eyebrow: "SOVEREIGN · MARKET",
    title: "Mozambique pilot. Colombia expansion.",
    body: "The opportunity is not another software category. It is the institutional financing of data as balance-sheet capital."
  }
];

function Reveal({ children, delay = 0 }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 28 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-80px" }}
      transition={{ duration: 0.9, ease: [0.22, 1, 0.36, 1], delay }}
    >
      {children}
    </motion.div>
  );
}

export default function App() {
  return (
    <main>
      <section className="hero">
        <div className="gradient-field" />
        <Reveal>
          <p className="eyebrow">ORTRAX · ONE2B</p>
          <h1>The world’s first insurance-backed data valuation company.</h1>
          <p className="lede">
            A softer institutional visual system for a serious capital-market category:
            IVSC-compliant valuation, insured transaction confidence, and sovereign-grade data infrastructure.
          </p>
        </Reveal>
      </section>

      <section className="narrative">
        {sections.map((section, index) => (
          <Reveal key={section.title} delay={index * 0.08}>
            <article className="story-block">
              <p className="eyebrow">{section.eyebrow}</p>
              <h2>{section.title}</h2>
              <p>{section.body}</p>
            </article>
          </Reveal>
        ))}
      </section>

      <section className="closing">
        <Reveal>
          <p className="eyebrow">QUIETLY · GOING · TO · MARKET</p>
          <h2>Insurance-backed data valuation, designed for capital allocators.</h2>
          <p>
            Registered Lloyd’s of London broker. Working with major global insurance conglomerates.
          </p>
        </Reveal>
      </section>
    </main>
  );
}
