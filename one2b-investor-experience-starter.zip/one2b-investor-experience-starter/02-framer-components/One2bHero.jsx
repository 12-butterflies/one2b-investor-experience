import * as React from "react";
import { motion } from "framer-motion";

export default function One2bHero() {
  return (
    <section style={styles.hero}>
      <div style={styles.gradient} />
      <motion.div
        style={styles.content}
        initial={{ opacity: 0, y: 28 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.9, ease: [0.22, 1, 0.36, 1] }}
      >
        <p style={styles.eyebrow}>ORTRAX · ONE2B</p>
        <h1 style={styles.title}>The world’s first insurance-backed data valuation company.</h1>
        <p style={styles.lede}>
          IVSC-compliant valuation through Tesseract. Transaction confidence through IGI.
        </p>
      </motion.div>
    </section>
  );
}

const styles = {
  hero: {
    minHeight: "100vh",
    position: "relative",
    display: "flex",
    alignItems: "center",
    padding: "8vw",
    background: "#FFFFFF",
    overflow: "hidden",
    fontFamily: "Inter, system-ui, sans-serif"
  },
  gradient: {
    position: "absolute",
    top: "-18vw",
    right: "-18vw",
    width: "62vw",
    height: "62vw",
    borderRadius: 999,
    background: "radial-gradient(circle at 30% 30%, #EAE4F4, transparent 36%), radial-gradient(circle at 62% 44%, #D2DCEC, transparent 38%), radial-gradient(circle at 54% 68%, #F1DDD0, transparent 42%)",
    filter: "blur(18px)",
    opacity: 0.92
  },
  content: {
    position: "relative",
    zIndex: 1,
    maxWidth: 1080
  },
  eyebrow: {
    fontSize: 12,
    letterSpacing: "0.26em",
    textTransform: "uppercase",
    color: "#4A5266",
    marginBottom: 24
  },
  title: {
    fontSize: "clamp(64px, 9vw, 160px)",
    lineHeight: 0.94,
    letterSpacing: "-0.055em",
    fontWeight: 300,
    color: "#1B2540",
    margin: 0
  },
  lede: {
    marginTop: 32,
    color: "#4A5266",
    fontSize: "clamp(18px, 1.6vw, 24px)",
    lineHeight: 1.55,
    maxWidth: 680
  }
};
