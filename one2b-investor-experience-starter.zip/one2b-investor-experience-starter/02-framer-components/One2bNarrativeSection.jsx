import * as React from "react";
import { motion } from "framer-motion";

export default function One2bNarrativeSection({
  eyebrow = "VALUATION · ASSURANCE",
  title = "The unlock is confidence.",
  body = "Tesseract establishes valuation discipline. IGI provides a 30-day repayment guarantee on qualified data-purchase transactions."
}) {
  return (
    <section style={styles.section}>
      <motion.article
        style={styles.article}
        initial={{ opacity: 0, y: 28 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true, margin: "-80px" }}
        transition={{ duration: 0.9, ease: [0.22, 1, 0.36, 1] }}
      >
        <p style={styles.eyebrow}>{eyebrow}</p>
        <h2 style={styles.title}>{title}</h2>
        <p style={styles.body}>{body}</p>
      </motion.article>
    </section>
  );
}

const styles = {
  section: {
    padding: "10vw 8vw",
    background: "#FFFFFF",
    fontFamily: "Inter, system-ui, sans-serif"
  },
  article: {
    maxWidth: 980
  },
  eyebrow: {
    fontSize: 12,
    letterSpacing: "0.26em",
    textTransform: "uppercase",
    color: "#4A5266",
    marginBottom: 24
  },
  title: {
    fontSize: "clamp(48px, 6.8vw, 112px)",
    lineHeight: 0.94,
    letterSpacing: "-0.055em",
    fontWeight: 300,
    color: "#1B2540",
    margin: 0
  },
  body: {
    marginTop: 32,
    color: "#4A5266",
    fontSize: "clamp(18px, 1.6vw, 24px)",
    lineHeight: 1.55,
    maxWidth: 680
  }
};
