import * as React from "react";
import { motion } from "framer-motion";

export default function One2bClosing() {
  return (
    <section style={styles.section}>
      <motion.div
        initial={{ opacity: 0, y: 28 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true, margin: "-80px" }}
        transition={{ duration: 0.9, ease: [0.22, 1, 0.36, 1] }}
      >
        <p style={styles.eyebrow}>QUIETLY · GOING · TO · MARKET</p>
        <h2 style={styles.title}>Insurance-backed data valuation, designed for capital allocators.</h2>
        <p style={styles.body}>
          Registered Lloyd’s of London broker. Working with major global insurance conglomerates.
        </p>
      </motion.div>
    </section>
  );
}

const styles = {
  section: {
    minHeight: "92vh",
    display: "flex",
    alignItems: "center",
    padding: "8vw",
    background: "linear-gradient(135deg, #FFFFFF 0%, #F8F5FA 44%, #F8F1EC 100%)",
    fontFamily: "Inter, system-ui, sans-serif"
  },
  eyebrow: {
    fontSize: 12,
    letterSpacing: "0.26em",
    textTransform: "uppercase",
    color: "#4A5266",
    marginBottom: 24
  },
  title: {
    fontSize: "clamp(48px, 6.8vw, 112px)",
    lineHeight: 0.94,
    letterSpacing: "-0.055em",
    fontWeight: 300,
    color: "#1B2540",
    margin: 0,
    maxWidth: 960
  },
  body: {
    marginTop: 32,
    color: "#4A5266",
    fontSize: "clamp(18px, 1.6vw, 24px)",
    lineHeight: 1.55,
    maxWidth: 680
  }
};
