# Framer Components

Paste these files into Framer Code Components.

Recommended order:
1. `One2bHero.jsx`
2. `One2bNarrativeSection.jsx`
3. `One2bClosing.jsx`

Use these as controlled visual blocks inside the Framer canvas.
